import path from "node:path";
import {
	attachSession,
	formatSessionTable,
	listSessions,
	startSession,
	stopSession,
} from "./runtime";

const HELP_TEXT = `pencil <command>

Commands:
  list                 List running Pencil sessions
  start <file>         Start or reuse a local-first Pencil session
  stop <session-id>    Stop a running Pencil session
  attach <session-id>  Print the attach URL for a running session`;

export async function runPencilCli(argv: string[]) {
	const [command, ...rest] = argv;

	if (!command || command === "--help" || command === "-h" || command === "help") {
		console.log(HELP_TEXT);
		return;
	}

	if (command === "list") {
		console.log(formatSessionTable(await listSessions()));
		return;
	}

	if (command === "start") {
		const entryFile = rest[0];
		if (!entryFile) {
			throw new Error("Usage: pencil start <file>");
		}
		const record = await startSession({ cwd: process.cwd(), entryFile });
		console.log(`Started ${record.sessionId}`);
		console.log(`File: ${record.entryFile}`);
		console.log(`Attach: ${record.attachUrl}`);
		return;
	}

	if (command === "stop") {
		const sessionId = rest[0];
		if (!sessionId) {
			throw new Error("Usage: pencil stop <session-id>");
		}
		const stopped = await stopSession(sessionId);
		if (!stopped) {
			throw new Error(`No active Pencil session found for ${sessionId}`);
		}
		console.log(`Stopped ${stopped.sessionId}`);
		return;
	}

	if (command === "attach") {
		const sessionId = rest[0];
		if (!sessionId) {
			throw new Error("Usage: pencil attach <session-id>");
		}
		const record = await attachSession(sessionId);
		if (!record) {
			throw new Error(`No active Pencil session found for ${sessionId}`);
		}
		console.log(record.attachUrl);
		return;
	}

	throw new Error(`Unknown command: ${command}${path.delimiter === ";" ? "" : ""}`);
}
