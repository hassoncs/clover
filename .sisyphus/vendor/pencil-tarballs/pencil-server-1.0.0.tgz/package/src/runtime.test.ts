import { describe, expect, it } from "vitest";

import {
	buildAttachUrl,
	createSessionRecord,
	removeSessionRecord,
	upsertSessionRecord,
	type PencilSessionRegistry,
} from "./runtime";

describe("pencil runtime session records", () => {
	it("derives standalone session metadata from a document file", () => {
		const record = createSessionRecord({
			cwd: "/Users/hassoncs/Workspaces/personal/pencil",
			entryFile: "/tmp/project-a/documents/main.pen",
			pid: 4242,
			port: 8090,
			startedAt: 1710000000000,
		});

		expect(record.sessionId).toMatch(/^pencil_[a-z0-9]+$/);
		expect(record.projectRoot).toBe("/tmp/project-a");
		expect(record.filePath).toBe("documents/main.pen");
		expect(record.entryFile).toBe("/tmp/project-a/documents/main.pen");
		expect(record.attachUrl).toBe(
			"http://localhost:8089?sessionId=" +
				record.sessionId +
				"&projectRoot=%2Ftmp%2Fproject-a&filePath=documents%2Fmain.pen&serverUrl=ws%3A%2F%2Flocalhost%3A8090%2Fws",
		);
	});

	it("keeps registry updates idempotent per session id", () => {
		const registry: PencilSessionRegistry = {
			version: 1,
			sessions: [],
		};
		const record = createSessionRecord({
			cwd: "/repo",
			entryFile: "/tmp/project-a/main.pen",
			pid: 111,
			port: 8123,
			startedAt: 1710000000000,
		});

		const withSession = upsertSessionRecord(registry, record);
		const updated = upsertSessionRecord(withSession, {
			...record,
			pid: 222,
		});

		expect(withSession.sessions).toHaveLength(1);
		expect(updated.sessions).toHaveLength(1);
		expect(updated.sessions[0]?.pid).toBe(222);
		expect(removeSessionRecord(updated, record.sessionId).sessions).toHaveLength(0);
	});
});

describe("buildAttachUrl", () => {
	it("allows explicit app origins for attach command output", () => {
		expect(
			buildAttachUrl({
				appOrigin: "http://127.0.0.1:4010/embed",
				filePath: "documents/main.pen",
				projectRoot: "/tmp/project-a",
				sessionId: "pencil_demo",
				serverUrl: "ws://127.0.0.1:8099/ws",
			}),
		).toBe(
			"http://127.0.0.1:4010/embed?sessionId=pencil_demo&projectRoot=%2Ftmp%2Fproject-a&filePath=documents%2Fmain.pen&serverUrl=ws%3A%2F%2F127.0.0.1%3A8099%2Fws",
		);
	});
});
