import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import { type PenDocument, parsePenDocument } from "@pencil/protocol/pen";
import express from "express";
import fs from "node:fs/promises";
import path from "node:path";
import { WebSocket, WebSocketServer } from "ws";
import { z } from "zod";
import { applyDesignChatOpsToDocument } from "./designChatOps.js";

export interface StandalonePencilServerConfig {
	host: string;
	port: number;
	sessionId: string;
	projectRoot: string;
	filePath: string;
	entryFile: string;
}

function createEmptyDocument(): PenDocument {
	return { version: 1, children: [] };
}

async function loadDocument(canvasFile: string): Promise<PenDocument> {
	try {
		const data = await fs.readFile(canvasFile, "utf-8");
		return parsePenDocument(JSON.parse(data));
	} catch {
		return createEmptyDocument();
	}
}

async function saveDocument(canvasFile: string, doc: PenDocument) {
	await fs.mkdir(path.dirname(canvasFile), { recursive: true });
	await fs.writeFile(canvasFile, JSON.stringify(doc, null, 2));
}

function calculateCenter(opsArray: unknown[]): { x?: number; y?: number } {
	for (const op of opsArray as Array<Record<string, any>>) {
		if (op.type === "addFrame" || op.type === "addElement") {
			const target = op.type === "addFrame" ? op : op.element;
			if (target && typeof target.x === "number" && typeof target.y === "number") {
				return {
					x: target.x + (target.width || 100) / 2,
					y: target.y + (target.height || 100) / 2,
				};
			}
		} else if (
			op.type === "updateElement" &&
			op.patch &&
			typeof op.patch.x === "number" &&
			typeof op.patch.y === "number"
		) {
			return { x: op.patch.x, y: op.patch.y };
		}
	}
	return { x: 500, y: 500 };
}

export async function startStandalonePencilServer(
	config: StandalonePencilServerConfig,
) {
	let document = await loadDocument(config.entryFile);
	let activeTransport: SSEServerTransport | null = null;

	const server = new McpServer({
		name: "pencil-server",
		version: "1.0.0",
	});
	const wss = new WebSocketServer({ noServer: true });

	function broadcastState() {
		const state = JSON.stringify({ type: "state_update", payload: document });
		for (const client of wss.clients) {
			if (client.readyState === WebSocket.OPEN) {
				client.send(state);
			}
		}
	}

	function broadcastAgentCursor(opsArray: unknown[]) {
		const { x, y } = calculateCenter(opsArray);
		const cursor = JSON.stringify({
			type: "agent_cursor_moved",
			payload: {
				agentId: "pencil-runtime",
				x,
				y,
				action: `Applying ${opsArray.length} operation(s)...`,
				timestamp: Date.now(),
			},
		});

		for (const client of wss.clients) {
			if (client.readyState === WebSocket.OPEN) {
				client.send(cursor);
			}
		}
	}

	server.tool(
		"pencil_batch_design",
		"Apply batch operations to the active Pencil document.",
		{
			filePath: z.string().optional(),
			operations: z.string(),
		},
		async ({ operations }) => {
			try {
				const opsArray = JSON.parse(operations) as unknown[];
				broadcastAgentCursor(opsArray);
				const result = applyDesignChatOpsToDocument(document, opsArray);
				document = result.nextDocument;
				await saveDocument(config.entryFile, document);
				broadcastState();

				return {
					content: [
						{
							type: "text",
							text: `Applied ${result.appliedOps} operations. Errors: ${result.errors.join(", ")}`,
						},
					],
				};
			} catch (error) {
				return {
					content: [{ type: "text", text: `Error: ${String(error)}` }],
				};
			}
		},
	);

	const app = express();
	app.use(express.json());

	app.get("/mcp", async (_req, res) => {
		const transport = new SSEServerTransport("/mcp/messages", res);
		activeTransport = transport;
		await server.connect(transport);
	});

	app.post("/mcp/messages", async (req, res) => {
		if (!activeTransport) {
			res.status(400).send("No active MCP session");
			return;
		}
		await activeTransport.handlePostMessage(req, res);
	});

	app.get("/health", (_req, res) => {
		res.json({
			status: "ok",
			port: config.port,
			sessionId: config.sessionId,
			projectRoot: config.projectRoot,
			filePath: config.filePath,
			entryFile: config.entryFile,
		});
	});

	const httpServer = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
		const serverInstance = app.listen(config.port, config.host, () => resolve(serverInstance));
	});

	httpServer.on("upgrade", (request, socket, head) => {
		if (request.url === "/ws") {
			wss.handleUpgrade(request, socket, head, (ws) => {
				wss.emit("connection", ws, request);
			});
		} else {
			socket.destroy();
		}
	});

	wss.on("connection", (ws) => {
		ws.send(JSON.stringify({ type: "state_update", payload: document }));

		ws.on("message", async (data) => {
			try {
				const msg = JSON.parse(data.toString()) as {
					type?: string;
					payload?: { ops?: unknown[] };
					ops?: unknown[];
				};
				if (msg.type === "delta" && Array.isArray(msg.payload?.ops)) {
					const result = applyDesignChatOpsToDocument(document, msg.payload.ops);
					document = result.nextDocument;
					await saveDocument(config.entryFile, document);
					broadcastState();
				} else if (msg.type === "chat_op" && Array.isArray(msg.ops)) {
					const result = applyDesignChatOpsToDocument(document, msg.ops);
					document = result.nextDocument;
					await saveDocument(config.entryFile, document);
					broadcastState();
				}
			} catch (error) {
				console.error("Failed to process socket message", error);
			}
		});
	});

	return {
		close: async () => {
			await new Promise<void>((resolve, reject) => {
				httpServer.close((error) => {
					if (error) reject(error);
					else resolve();
				});
			});
			wss.close();
		},
	};
}
