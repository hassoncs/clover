import { createRequire } from "node:module";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import { fileURLToPath, URL } from "node:url";

const DEFAULT_APP_ORIGIN = "http://localhost:8089";
const DEFAULT_RUNTIME_HOME = path.join(os.homedir(), ".pencil", "runtime");
const DEFAULT_HOST = "localhost";
const DEFAULT_PORT_START = 8090;

export interface PencilSessionRecord {
	sessionId: string;
	projectRoot: string;
	filePath: string;
	entryFile: string;
	pid: number;
	port: number;
	startedAt: number;
	serverUrl: string;
	attachUrl: string;
	host: string;
}

export interface PencilSessionRegistry {
	version: 1;
	sessions: PencilSessionRecord[];
}

export function buildAttachUrl({
	appOrigin = DEFAULT_APP_ORIGIN,
	filePath,
	projectRoot,
	sessionId,
	serverUrl,
}: {
	appOrigin?: string;
	filePath: string;
	projectRoot: string;
	sessionId: string;
	serverUrl: string;
}): string {
	const url = new URL(appOrigin);
	url.searchParams.set("sessionId", sessionId);
	url.searchParams.set("projectRoot", projectRoot);
	url.searchParams.set("filePath", filePath);
	url.searchParams.set("serverUrl", serverUrl);
	const normalized = url.toString();
	if (url.pathname === "/") {
		return normalized.replace("/?", "?");
	}
	return normalized;
}

function simpleHash(value: string): string {
	let hash = 5381;
	for (let i = 0; i < value.length; i += 1) {
		hash = ((hash << 5) + hash) ^ value.charCodeAt(i);
	}
	return (hash >>> 0).toString(36);
}

function normalizeEntryFile(filePath: string, cwd: string): string {
	return path.resolve(cwd, filePath);
}

function resolveProjectRoot(entryFile: string): { projectRoot: string; filePath: string } {
	const normalized = entryFile.split(path.sep);
	const documentsIndex = normalized.lastIndexOf("documents");
	if (documentsIndex > 0) {
		const projectRoot = normalized.slice(0, documentsIndex).join(path.sep) || path.sep;
		const relativeFilePath = normalized.slice(documentsIndex).join(path.sep);
		return { projectRoot, filePath: relativeFilePath };
	}

	return {
		projectRoot: path.dirname(entryFile),
		filePath: path.basename(entryFile),
	};
}

export function createSessionRecord({
	appOrigin,
	cwd,
	entryFile,
	host = DEFAULT_HOST,
	pid,
	port,
	startedAt,
}: {
	appOrigin?: string;
	cwd: string;
	entryFile: string;
	host?: string;
	pid: number;
	port: number;
	startedAt: number;
}): PencilSessionRecord {
	const absoluteEntryFile = normalizeEntryFile(entryFile, cwd);
	const { projectRoot, filePath } = resolveProjectRoot(absoluteEntryFile);
	const sessionId = `pencil_${simpleHash(absoluteEntryFile)}`;
	const serverUrl = `ws://${host}:${port}/ws`;

	return {
		sessionId,
		projectRoot,
		filePath,
		entryFile: absoluteEntryFile,
		pid,
		port,
		startedAt,
		host,
		serverUrl,
		attachUrl: buildAttachUrl({
			appOrigin,
			filePath,
			projectRoot,
			sessionId,
			serverUrl,
		}),
	};
}

export function upsertSessionRecord(
	registry: PencilSessionRegistry,
	record: PencilSessionRecord,
): PencilSessionRegistry {
	return {
		version: 1,
		sessions: [...registry.sessions.filter((item) => item.sessionId !== record.sessionId), record].sort(
			(a, b) => a.startedAt - b.startedAt,
		),
	};
}

export function removeSessionRecord(
	registry: PencilSessionRegistry,
	sessionId: string,
): PencilSessionRegistry {
	return {
		version: 1,
		sessions: registry.sessions.filter((item) => item.sessionId !== sessionId),
	};
}

export function resolveRuntimeHome(): string {
	return process.env.PENCIL_RUNTIME_HOME || DEFAULT_RUNTIME_HOME;
}

export function resolveRegistryPath(): string {
	return path.join(resolveRuntimeHome(), "sessions.json");
}

async function ensureRuntimeHome() {
	await fs.mkdir(resolveRuntimeHome(), { recursive: true });
}

export async function readSessionRegistry(): Promise<PencilSessionRegistry> {
	try {
		const raw = await fs.readFile(resolveRegistryPath(), "utf8");
		const parsed = JSON.parse(raw) as PencilSessionRegistry;
		return {
			version: 1,
			sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
		};
	} catch {
		return { version: 1, sessions: [] };
	}
}

export async function writeSessionRegistry(registry: PencilSessionRegistry) {
	await ensureRuntimeHome();
	await fs.writeFile(resolveRegistryPath(), `${JSON.stringify(registry, null, 2)}\n`);
}

export function isProcessRunning(pid: number): boolean {
	try {
		process.kill(pid, 0);
		return true;
	} catch {
		return false;
	}
}

export async function pruneDeadSessions(
	registry: PencilSessionRegistry,
): Promise<PencilSessionRegistry> {
	const liveSessions = registry.sessions.filter((session) => isProcessRunning(session.pid));
	const nextRegistry = { version: 1 as const, sessions: liveSessions };
	if (liveSessions.length !== registry.sessions.length) {
		await writeSessionRegistry(nextRegistry);
	}
	return nextRegistry;
}

async function canListenOnPort(port: number): Promise<boolean> {
	return new Promise((resolve) => {
		const server = net.createServer();
		server.once("error", () => resolve(false));
		server.listen(port, DEFAULT_HOST, () => {
			server.close(() => resolve(true));
		});
	});
}

async function findAvailablePort(registry: PencilSessionRegistry): Promise<number> {
	const used = new Set(registry.sessions.map((session) => session.port));
	let port = DEFAULT_PORT_START;
	while (used.has(port) || !(await canListenOnPort(port))) {
		port += 1;
	}
	return port;
}

function resolveTsxCliPath(): string {
	const require = createRequire(import.meta.url);
	return require.resolve("tsx/cli");
}

function resolveWorkerPath(): string {
	return fileURLToPath(new URL("./worker.ts", import.meta.url));
}

function spawnSessionWorker(record: PencilSessionRecord, cwd: string): number {
	const child = spawn(process.execPath, [resolveTsxCliPath(), resolveWorkerPath()], {
		cwd,
		detached: true,
		stdio: "ignore",
		env: {
			...process.env,
			PENCIL_SESSION_ID: record.sessionId,
			PENCIL_PROJECT_ROOT: record.projectRoot,
			PENCIL_FILE_PATH: record.filePath,
			PENCIL_ENTRY_FILE: record.entryFile,
			PENCIL_PORT: String(record.port),
			PENCIL_HOST: record.host,
		},
	});
	child.unref();
	if (!child.pid) {
		throw new Error("Failed to start Pencil session worker");
	}
	return child.pid;
}

export async function listSessions(): Promise<PencilSessionRegistry> {
	return pruneDeadSessions(await readSessionRegistry());
}

export async function startSession({
	appOrigin,
	cwd,
	entryFile,
}: {
	appOrigin?: string;
	cwd: string;
	entryFile: string;
}): Promise<PencilSessionRecord> {
	const absoluteEntryFile = normalizeEntryFile(entryFile, cwd);
	await fs.access(absoluteEntryFile);

	const liveRegistry = await listSessions();
	const existing = liveRegistry.sessions.find((session) => session.entryFile === absoluteEntryFile);
	if (existing) {
		return existing;
	}

	const port = await findAvailablePort(liveRegistry);
	const startedAt = Date.now();
	const seedRecord = createSessionRecord({
		appOrigin,
		cwd,
		entryFile: absoluteEntryFile,
		host: DEFAULT_HOST,
		pid: process.pid,
		port,
		startedAt,
	});
	const pid = spawnSessionWorker(seedRecord, cwd);
	const record = { ...seedRecord, pid };
	await writeSessionRegistry(upsertSessionRecord(liveRegistry, record));
	return record;
}

export async function stopSession(sessionId: string): Promise<PencilSessionRecord | null> {
	const liveRegistry = await listSessions();
	const record = liveRegistry.sessions.find((session) => session.sessionId === sessionId) ?? null;
	if (!record) {
		return null;
	}

	try {
		process.kill(record.pid, "SIGTERM");
	} catch {
	}

	await writeSessionRegistry(removeSessionRecord(liveRegistry, sessionId));
	return record;
}

export async function attachSession(sessionId: string): Promise<PencilSessionRecord | null> {
	const liveRegistry = await listSessions();
	return liveRegistry.sessions.find((session) => session.sessionId === sessionId) ?? null;
}

export function formatSessionTable(registry: PencilSessionRegistry): string {
	if (registry.sessions.length === 0) {
		return "No active Pencil sessions.";
	}

	return [
		"SESSION ID           PORT  PROJECT ROOT                  FILE",
		...registry.sessions.map((session) => {
			const paddedId = session.sessionId.padEnd(20, " ");
			const paddedPort = String(session.port).padEnd(5, " ");
			const paddedRoot = session.projectRoot.padEnd(29, " ");
			return `${paddedId} ${paddedPort} ${paddedRoot} ${session.filePath}`;
		}),
	].join("\n");
}
