import { startStandalonePencilServer, type StandalonePencilServerConfig } from "./server";

function readRequiredEnv(name: string): string {
	const value = process.env[name]?.trim();
	if (!value) {
		throw new Error(`Missing required env var: ${name}`);
	}
	return value;
}

export function readStandaloneServerConfigFromEnv(): StandalonePencilServerConfig {
	return {
		host: process.env.PENCIL_HOST?.trim() || "127.0.0.1",
		port: Number(readRequiredEnv("PENCIL_PORT")),
		sessionId: readRequiredEnv("PENCIL_SESSION_ID"),
		projectRoot: readRequiredEnv("PENCIL_PROJECT_ROOT"),
		filePath: readRequiredEnv("PENCIL_FILE_PATH"),
		entryFile: readRequiredEnv("PENCIL_ENTRY_FILE"),
	};
}

export async function runStandalonePencilServerFromEnv() {
	await startStandalonePencilServer(readStandaloneServerConfigFromEnv());
}

if (import.meta.url === `file://${process.argv[1]}`) {
	void runStandalonePencilServerFromEnv().catch((error) => {
		console.error(error instanceof Error ? error.message : String(error));
		process.exitCode = 1;
	});
}
